﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yerelisletme
{
    public partial class FormIsletmePanel : Form
    {
        public FormIsletmePanel()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void btnYogunlukAnaliz_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Müşteri Yoğunluğu Analizi ekranı açılacak.");
            
        }

        private void btnPersonelPlanlama_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Personel Planlama ekranı açılacak.");
        }

        private void btnMevsimselTrend_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mevsimsel Trend ekranı açılacak.");
        }

        private void btnGelirAnalizi_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Gelir Optimizasyonu ekranı açılacak.");
        }

        private void btnYogunlukAnaliz_Click_1(object sender, EventArgs e)
        {
            MusteriYogunluguAnalizics panel = new MusteriYogunluguAnalizics();
            panel.Show();
            this.Hide();
        }

        private void btnMevsimselTrend_Click_1(object sender, EventArgs e)
        {
            MevsimselTrend panel = new MevsimselTrend();
            panel.Show();
            this.Hide();
        }

        private void btnPersonelPlanlama_Click_1(object sender, EventArgs e)
        {
            PersonelPlanlama panel = new PersonelPlanlama();
            panel.Show();
            this.Hide();
        }

        private void btnGelirAnalizi_Click_1(object sender, EventArgs e)
        {
            GelirOPT panel = new GelirOPT();
            panel.Show();
            this.Hide();
        }

        private void FormIsletmePanel_Load(object sender, EventArgs e)
        {

        }
    }
}
