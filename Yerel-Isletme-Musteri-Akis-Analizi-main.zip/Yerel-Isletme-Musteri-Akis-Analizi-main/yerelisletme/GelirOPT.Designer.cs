﻿namespace yerelisletme
{
    partial class GelirOPT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGelirAnaliz = new System.Windows.Forms.Button();
            this.dataGridGelir = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.lblToplamGelir = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGelir)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGelirAnaliz
            // 
            this.btnGelirAnaliz.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGelirAnaliz.Location = new System.Drawing.Point(216, 351);
            this.btnGelirAnaliz.Name = "btnGelirAnaliz";
            this.btnGelirAnaliz.Size = new System.Drawing.Size(175, 64);
            this.btnGelirAnaliz.TabIndex = 0;
            this.btnGelirAnaliz.Text = "Geliri Optimize Et";
            this.btnGelirAnaliz.UseVisualStyleBackColor = true;
            this.btnGelirAnaliz.Click += new System.EventHandler(this.btnGelirAnaliz_Click);
            // 
            // dataGridGelir
            // 
            this.dataGridGelir.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridGelir.Location = new System.Drawing.Point(76, 86);
            this.dataGridGelir.Name = "dataGridGelir";
            this.dataGridGelir.RowHeadersWidth = 51;
            this.dataGridGelir.RowTemplate.Height = 24;
            this.dataGridGelir.Size = new System.Drawing.Size(649, 246);
            this.dataGridGelir.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(407, 351);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 64);
            this.button1.TabIndex = 3;
            this.button1.Text = "Menü";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblToplamGelir
            // 
            this.lblToplamGelir.AutoSize = true;
            this.lblToplamGelir.Location = new System.Drawing.Point(409, 27);
            this.lblToplamGelir.Name = "lblToplamGelir";
            this.lblToplamGelir.Size = new System.Drawing.Size(10, 16);
            this.lblToplamGelir.TabIndex = 4;
            this.lblToplamGelir.Text = "l";
            // 
            // GelirOPT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblToplamGelir);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridGelir);
            this.Controls.Add(this.btnGelirAnaliz);
            this.Name = "GelirOPT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GelirOPT";
            this.Load += new System.EventHandler(this.GelirOPT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridGelir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGelirAnaliz;
        private System.Windows.Forms.DataGridView dataGridGelir;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblToplamGelir;
    }
}