﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.NetworkInformation;

namespace yerelisletme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string connectionString = @"Server=BEDIRHANSVICTUS\SQLEXPRESS;Database=YerelIsletmeDB;Trusted_Connection=True;";

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnIsletmeGiris_Click(object sender, EventArgs e)
        {
            string kullanici = txtIsletmeKullanici.Text;
            string sifre = txtIsletmeSifre.Text;

            try
            {
                using (SqlConnection baglanti = new SqlConnection(connectionString))
                {
                    string sorgu = "SELECT Yetki FROM Kullanicilar WHERE KullaniciAdi=@kadi AND Sifre=@sifre";
                    SqlCommand komut = new SqlCommand(sorgu, baglanti);
                    komut.Parameters.AddWithValue("@kadi", kullanici);
                    komut.Parameters.AddWithValue("@sifre", sifre);

                    baglanti.Open();
                    object sonuc = komut.ExecuteScalar(); 

                    if (sonuc != null && sonuc.ToString() == "isletme")
                    {
                        FormIsletmePanel panel = new FormIsletmePanel();
                        panel.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("İşletme bilgileri hatalı veya yetkisiz!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("HATA: " + ex.Message);
            }
        }

        private void btnPersonelGiris_Click_1(object sender, EventArgs e)
        {
            string kullanici = txtPersonelKullanici.Text;
            string sifre = txtPersonelSifre.Text;

            try
            {
                using (SqlConnection baglanti = new SqlConnection(connectionString))
                {
                    string sorgu = "SELECT Yetki FROM Kullanicilar WHERE KullaniciAdi=@kadi AND Sifre=@sifre";
                    SqlCommand komut = new SqlCommand(sorgu, baglanti);
                    komut.Parameters.AddWithValue("@kadi", kullanici);
                    komut.Parameters.AddWithValue("@sifre", sifre);

                    baglanti.Open();
                    object sonuc = komut.ExecuteScalar();

                    if (sonuc != null && sonuc.ToString() == "personel")
                    {
                        FormPersonelPanel panel = new FormPersonelPanel();
                        panel.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Personel bilgileri hatalı veya yetkisiz!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("HATA: " + ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
