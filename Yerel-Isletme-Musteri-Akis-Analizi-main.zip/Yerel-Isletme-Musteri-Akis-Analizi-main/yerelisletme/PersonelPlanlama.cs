﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yerelisletme
{
    public partial class PersonelPlanlama : Form
    {
        string connectionString = @"Server=BEDIRHANSVICTUS\SQLEXPRESS;Database=YerelIsletmeDB;Trusted_Connection=True;";
        public PersonelPlanlama()
        {
            InitializeComponent();
        }

        private void btnPlanlamaYap_Click(object sender, EventArgs e)
        {
            using (SqlConnection baglanti = new SqlConnection(connectionString))
            {
                string sorgu = @"
            SELECT 
                FORMAT(Saat, 'hh\:mm') AS Saat, 
                AVG(MusteriSayisi) AS OrtalamaMusteri
            FROM MusteriAkis
            GROUP BY FORMAT(Saat, 'hh\:mm')
            ORDER BY Saat";

                SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);

                
                dt.Columns.Add("PersonelOnerisi", typeof(string));

                foreach (DataRow row in dt.Rows)
                {
                    int musteri = Convert.ToInt32(row["OrtalamaMusteri"]);
                    string onerilen;

                    if (musteri <= 10)
                        onerilen = "1 personel yeterli";
                    else if (musteri <= 20)
                        onerilen = "2 personel önerilir";
                    else if (musteri <= 30)
                        onerilen = "3 personel önerilir";
                    else
                        onerilen = "4+ personel önerilir";

                    row["PersonelOnerisi"] = onerilen;
                }

                
                dataGridPersonelPlan.DataSource = dt;

              
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormIsletmePanel panel = new FormIsletmePanel();
            panel.Show();
            this.Hide();
        }
    }
}
