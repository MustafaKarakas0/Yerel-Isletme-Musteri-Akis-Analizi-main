﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yerelisletme
{
    public partial class MevsimselTrend : Form
    {
        string connectionString = @"Server=BEDIRHANSVICTUS\SQLEXPRESS;Database=YerelIsletmeDB;Trusted_Connection=True;";

        public MevsimselTrend()
        {
            InitializeComponent();
        }

        private void btnMevsimselGetir_Click(object sender, EventArgs e)
        {
            using (SqlConnection baglanti = new SqlConnection(connectionString))
            {
                string sorgu = @"
            SELECT
                CASE 
                    WHEN MONTH(Tarih) IN (12, 1, 2) THEN 'Kış'
                    WHEN MONTH(Tarih) IN (3, 4, 5) THEN 'İlkbahar'
                    WHEN MONTH(Tarih) IN (6, 7, 8) THEN 'Yaz'
                    WHEN MONTH(Tarih) IN (9, 10, 11) THEN 'Sonbahar'
                END AS Mevsim,
                AVG(Gelir) AS OrtalamaGelir
            FROM GelirKayit
            GROUP BY 
                CASE 
                    WHEN MONTH(Tarih) IN (12, 1, 2) THEN 'Kış'
                    WHEN MONTH(Tarih) IN (3, 4, 5) THEN 'İlkbahar'
                    WHEN MONTH(Tarih) IN (6, 7, 8) THEN 'Yaz'
                    WHEN MONTH(Tarih) IN (9, 10, 11) THEN 'Sonbahar'
                END";

                SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridMevsimsel.DataSource = dt;


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormIsletmePanel panel = new FormIsletmePanel();
            panel.Show();
            this.Hide();
        }
    }
}
