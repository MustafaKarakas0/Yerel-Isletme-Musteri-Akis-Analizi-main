﻿namespace yerelisletme
{
    partial class MevsimselTrend
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMevsimselGetir = new System.Windows.Forms.Button();
            this.dataGridMevsimsel = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMevsimsel)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMevsimselGetir
            // 
            this.btnMevsimselGetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMevsimselGetir.Location = new System.Drawing.Point(261, 347);
            this.btnMevsimselGetir.Name = "btnMevsimselGetir";
            this.btnMevsimselGetir.Size = new System.Drawing.Size(129, 54);
            this.btnMevsimselGetir.TabIndex = 0;
            this.btnMevsimselGetir.Text = "Mevsimsel Trendleri Göster";
            this.btnMevsimselGetir.UseVisualStyleBackColor = true;
            this.btnMevsimselGetir.Click += new System.EventHandler(this.btnMevsimselGetir_Click);
            // 
            // dataGridMevsimsel
            // 
            this.dataGridMevsimsel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridMevsimsel.Location = new System.Drawing.Point(109, 36);
            this.dataGridMevsimsel.Name = "dataGridMevsimsel";
            this.dataGridMevsimsel.RowHeadersWidth = 51;
            this.dataGridMevsimsel.RowTemplate.Height = 24;
            this.dataGridMevsimsel.Size = new System.Drawing.Size(583, 287);
            this.dataGridMevsimsel.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(428, 347);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 54);
            this.button1.TabIndex = 3;
            this.button1.Text = "Menü";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MevsimselTrend
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridMevsimsel);
            this.Controls.Add(this.btnMevsimselGetir);
            this.Name = "MevsimselTrend";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MevsimselTrend";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMevsimsel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMevsimselGetir;
        private System.Windows.Forms.DataGridView dataGridMevsimsel;
        private System.Windows.Forms.Button button1;
    }
}