﻿namespace yerelisletme
{
    partial class FormIsletmePanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnYogunlukAnaliz = new System.Windows.Forms.Button();
            this.btnPersonelPlanlama = new System.Windows.Forms.Button();
            this.btnMevsimselTrend = new System.Windows.Forms.Button();
            this.btnGelirAnalizi = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(366, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "İşletme Yönetim Paneli\n";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnYogunlukAnaliz
            // 
            this.btnYogunlukAnaliz.BackColor = System.Drawing.Color.Turquoise;
            this.btnYogunlukAnaliz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYogunlukAnaliz.ForeColor = System.Drawing.Color.White;
            this.btnYogunlukAnaliz.Location = new System.Drawing.Point(26, 34);
            this.btnYogunlukAnaliz.Name = "btnYogunlukAnaliz";
            this.btnYogunlukAnaliz.Size = new System.Drawing.Size(200, 69);
            this.btnYogunlukAnaliz.TabIndex = 1;
            this.btnYogunlukAnaliz.Text = "Müşteri Yoğunluğu Analizi";
            this.btnYogunlukAnaliz.UseVisualStyleBackColor = false;
            this.btnYogunlukAnaliz.Click += new System.EventHandler(this.btnYogunlukAnaliz_Click_1);
            // 
            // btnPersonelPlanlama
            // 
            this.btnPersonelPlanlama.BackColor = System.Drawing.Color.Red;
            this.btnPersonelPlanlama.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPersonelPlanlama.ForeColor = System.Drawing.Color.White;
            this.btnPersonelPlanlama.Location = new System.Drawing.Point(294, 34);
            this.btnPersonelPlanlama.Name = "btnPersonelPlanlama";
            this.btnPersonelPlanlama.Size = new System.Drawing.Size(200, 69);
            this.btnPersonelPlanlama.TabIndex = 2;
            this.btnPersonelPlanlama.Text = "Personel Planlama";
            this.btnPersonelPlanlama.UseVisualStyleBackColor = false;
            this.btnPersonelPlanlama.Click += new System.EventHandler(this.btnPersonelPlanlama_Click_1);
            // 
            // btnMevsimselTrend
            // 
            this.btnMevsimselTrend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnMevsimselTrend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMevsimselTrend.ForeColor = System.Drawing.Color.White;
            this.btnMevsimselTrend.Location = new System.Drawing.Point(26, 144);
            this.btnMevsimselTrend.Name = "btnMevsimselTrend";
            this.btnMevsimselTrend.Size = new System.Drawing.Size(200, 67);
            this.btnMevsimselTrend.TabIndex = 3;
            this.btnMevsimselTrend.Text = "Mevsimsel Trendler";
            this.btnMevsimselTrend.UseVisualStyleBackColor = false;
            this.btnMevsimselTrend.Click += new System.EventHandler(this.btnMevsimselTrend_Click_1);
            // 
            // btnGelirAnalizi
            // 
            this.btnGelirAnalizi.BackColor = System.Drawing.Color.Gold;
            this.btnGelirAnalizi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGelirAnalizi.ForeColor = System.Drawing.Color.White;
            this.btnGelirAnalizi.Location = new System.Drawing.Point(294, 144);
            this.btnGelirAnalizi.Name = "btnGelirAnalizi";
            this.btnGelirAnalizi.Size = new System.Drawing.Size(200, 67);
            this.btnGelirAnalizi.TabIndex = 4;
            this.btnGelirAnalizi.Text = "Gelir Optimizasyonu";
            this.btnGelirAnalizi.UseVisualStyleBackColor = false;
            this.btnGelirAnalizi.Click += new System.EventHandler(this.btnGelirAnalizi_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnMevsimselTrend);
            this.panel1.Controls.Add(this.btnYogunlukAnaliz);
            this.panel1.Controls.Add(this.btnPersonelPlanlama);
            this.panel1.Controls.Add(this.btnGelirAnalizi);
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel1.Location = new System.Drawing.Point(247, 159);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(515, 246);
            this.panel1.TabIndex = 5;
            // 
            // FormIsletmePanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 538);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "FormIsletmePanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IsletmePanel";
            this.Load += new System.EventHandler(this.FormIsletmePanel_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnYogunlukAnaliz;
        private System.Windows.Forms.Button btnPersonelPlanlama;
        private System.Windows.Forms.Button btnMevsimselTrend;
        private System.Windows.Forms.Button btnGelirAnalizi;
        private System.Windows.Forms.Panel panel1;
    }
}