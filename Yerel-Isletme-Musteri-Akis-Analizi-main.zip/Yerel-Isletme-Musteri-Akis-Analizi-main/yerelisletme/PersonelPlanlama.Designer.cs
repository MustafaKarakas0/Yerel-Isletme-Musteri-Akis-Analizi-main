﻿namespace yerelisletme
{
    partial class PersonelPlanlama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPlanlamaYap = new System.Windows.Forms.Button();
            this.dataGridPersonelPlan = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPersonelPlan)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPlanlamaYap
            // 
            this.btnPlanlamaYap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlanlamaYap.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPlanlamaYap.Location = new System.Drawing.Point(230, 359);
            this.btnPlanlamaYap.Name = "btnPlanlamaYap";
            this.btnPlanlamaYap.Size = new System.Drawing.Size(150, 66);
            this.btnPlanlamaYap.TabIndex = 0;
            this.btnPlanlamaYap.Text = "Personel Planlaması Yap";
            this.btnPlanlamaYap.UseVisualStyleBackColor = true;
            this.btnPlanlamaYap.Click += new System.EventHandler(this.btnPlanlamaYap_Click);
            // 
            // dataGridPersonelPlan
            // 
            this.dataGridPersonelPlan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridPersonelPlan.Location = new System.Drawing.Point(182, 73);
            this.dataGridPersonelPlan.Name = "dataGridPersonelPlan";
            this.dataGridPersonelPlan.RowHeadersWidth = 51;
            this.dataGridPersonelPlan.RowTemplate.Height = 24;
            this.dataGridPersonelPlan.Size = new System.Drawing.Size(453, 257);
            this.dataGridPersonelPlan.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(415, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 66);
            this.button1.TabIndex = 3;
            this.button1.Text = "Menü";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PersonelPlanlama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridPersonelPlan);
            this.Controls.Add(this.btnPlanlamaYap);
            this.Name = "PersonelPlanlama";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PersonelPlanlama";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridPersonelPlan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPlanlamaYap;
        private System.Windows.Forms.DataGridView dataGridPersonelPlan;
        private System.Windows.Forms.Button button1;
    }
}