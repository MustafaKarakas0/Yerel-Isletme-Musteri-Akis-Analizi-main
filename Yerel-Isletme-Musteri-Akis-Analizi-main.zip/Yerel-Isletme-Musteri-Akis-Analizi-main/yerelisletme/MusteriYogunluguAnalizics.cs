﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yerelisletme
{
    public partial class MusteriYogunluguAnalizics : Form
    {
        string connectionString = @"Server=BEDIRHANSVICTUS\SQLEXPRESS;Database=YerelIsletmeDB;Trusted_Connection=True;";

        public MusteriYogunluguAnalizics()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection baglanti = new SqlConnection(connectionString))
            {
                string sorgu = @"SELECT Saat, SUM(MusteriSayisi) AS ToplamMusteri
                             FROM MusteriAkis
                             GROUP BY Saat
                             ORDER BY Saat";

                SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridYogunluk.DataSource = dt;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FormIsletmePanel panel = new FormIsletmePanel();
            panel.Show();
            this.Hide();
        }
    }
}
