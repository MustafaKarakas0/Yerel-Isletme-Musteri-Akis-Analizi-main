﻿namespace yerelisletme
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnIsletmeGiris = new System.Windows.Forms.Button();
            this.txtIsletmeSifre = new System.Windows.Forms.TextBox();
            this.txtIsletmeKullanici = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPersonelGiris = new System.Windows.Forms.Button();
            this.txtPersonelSifre = new System.Windows.Forms.TextBox();
            this.txtPersonelKullanici = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnIsletmeGiris);
            this.groupBox1.Controls.Add(this.txtIsletmeSifre);
            this.groupBox1.Controls.Add(this.txtIsletmeKullanici);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(82, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 410);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İşletme Girişi";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnIsletmeGiris
            // 
            this.btnIsletmeGiris.Location = new System.Drawing.Point(181, 242);
            this.btnIsletmeGiris.Name = "btnIsletmeGiris";
            this.btnIsletmeGiris.Size = new System.Drawing.Size(120, 40);
            this.btnIsletmeGiris.TabIndex = 4;
            this.btnIsletmeGiris.Text = "Giriş Yap";
            this.btnIsletmeGiris.UseVisualStyleBackColor = true;
            this.btnIsletmeGiris.Click += new System.EventHandler(this.btnIsletmeGiris_Click);
            // 
            // txtIsletmeSifre
            // 
            this.txtIsletmeSifre.Location = new System.Drawing.Point(234, 154);
            this.txtIsletmeSifre.Name = "txtIsletmeSifre";
            this.txtIsletmeSifre.Size = new System.Drawing.Size(140, 34);
            this.txtIsletmeSifre.TabIndex = 3;
            // 
            // txtIsletmeKullanici
            // 
            this.txtIsletmeKullanici.Location = new System.Drawing.Point(234, 71);
            this.txtIsletmeKullanici.Name = "txtIsletmeKullanici";
            this.txtIsletmeKullanici.Size = new System.Drawing.Size(140, 34);
            this.txtIsletmeKullanici.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(136, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Şifre : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(66, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kullanıcı Adı :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnPersonelGiris);
            this.groupBox2.Controls.Add(this.txtPersonelSifre);
            this.groupBox2.Controls.Add(this.txtPersonelKullanici);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(565, 63);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 410);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personel Girişi";
            // 
            // btnPersonelGiris
            // 
            this.btnPersonelGiris.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPersonelGiris.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPersonelGiris.Location = new System.Drawing.Point(181, 242);
            this.btnPersonelGiris.Name = "btnPersonelGiris";
            this.btnPersonelGiris.Size = new System.Drawing.Size(120, 40);
            this.btnPersonelGiris.TabIndex = 4;
            this.btnPersonelGiris.Text = "Giriş Yap";
            this.btnPersonelGiris.UseVisualStyleBackColor = true;
            this.btnPersonelGiris.Click += new System.EventHandler(this.btnPersonelGiris_Click_1);
            // 
            // txtPersonelSifre
            // 
            this.txtPersonelSifre.Location = new System.Drawing.Point(234, 154);
            this.txtPersonelSifre.Name = "txtPersonelSifre";
            this.txtPersonelSifre.Size = new System.Drawing.Size(140, 34);
            this.txtPersonelSifre.TabIndex = 3;
            // 
            // txtPersonelKullanici
            // 
            this.txtPersonelKullanici.Location = new System.Drawing.Point(234, 71);
            this.txtPersonelKullanici.Name = "txtPersonelKullanici";
            this.txtPersonelKullanici.Size = new System.Drawing.Size(140, 34);
            this.txtPersonelKullanici.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(136, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 28);
            this.label3.TabIndex = 1;
            this.label3.Text = "Şifre : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(66, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 28);
            this.label4.TabIndex = 0;
            this.label4.Text = "Kullanıcı Adı :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1094, 531);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yerel İşletme Müşteri Akışı Analiz Uygulaması";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnIsletmeGiris;
        private System.Windows.Forms.TextBox txtIsletmeSifre;
        private System.Windows.Forms.TextBox txtIsletmeKullanici;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPersonelGiris;
        private System.Windows.Forms.TextBox txtPersonelSifre;
        private System.Windows.Forms.TextBox txtPersonelKullanici;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

