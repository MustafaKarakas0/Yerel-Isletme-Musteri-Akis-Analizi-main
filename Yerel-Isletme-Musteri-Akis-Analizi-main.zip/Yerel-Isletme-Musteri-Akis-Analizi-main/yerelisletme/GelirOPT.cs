﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yerelisletme
{
    public partial class GelirOPT : Form
    {
        string connectionString = @"Server=BEDIRHANSVICTUS\SQLEXPRESS;Database=YerelIsletmeDB;Trusted_Connection=True;";
        public GelirOPT()
        {
            InitializeComponent();
        }

        private void btnGelirAnaliz_Click(object sender, EventArgs e)
        {
            using (SqlConnection baglanti = new SqlConnection(connectionString))
            {
                string sorgu = @"
            SELECT 
                FORMAT(Saat, 'hh\:mm') AS Saat, 
                SUM(MusteriSayisi) AS ToplamMusteri,
                AVG(OrtalamaHarcama) AS OrtalamaHarcama,
                SUM(MusteriSayisi * OrtalamaHarcama) AS ToplamGelir
            FROM Satislar
            GROUP BY FORMAT(Saat, 'hh\:mm')
            ORDER BY Saat";

                SqlDataAdapter da = new SqlDataAdapter(sorgu, baglanti);
                DataTable dt = new DataTable();
                da.Fill(dt);

                
                decimal toplamGunlukGelir = 0;
                foreach (DataRow row in dt.Rows)
                {
                    toplamGunlukGelir += Convert.ToDecimal(row["ToplamGelir"]);
                }

                dataGridGelir.DataSource = dt;
                lblToplamGelir.Text = "Toplam Günlük Gelir: ₺" + toplamGunlukGelir.ToString("N2");


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormIsletmePanel panel = new FormIsletmePanel();
            panel.Show();
            this.Hide();
        }

        private void GelirOPT_Load(object sender, EventArgs e)
        {

        }
    }
}
